<?php
namespace Mvc\Service;

class MailService {
	
	
	public function __construct(){
		echo '<h3 style="color:red;font-weight:bold">' . __METHOD__ . '</h3>';
	}
	
}