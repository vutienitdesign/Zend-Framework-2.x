<?php

return array (
	'controllers'	=> array(
		'invokables'	=> array(
				'Training\Controller\Index'				=> 'Training\Controller\IndexController',
				'Training\Controller\Config'			=> 'Training\Controller\ConfigController',
				'Training\Controller\Autoloader'		=> 'Training\Controller\AutoloaderController',
			)
	),
// 	'view_manager'	=> array(
// 		'template_path_stack'	=> array(__DIR__ . '/../view'),
// 	),

		
);