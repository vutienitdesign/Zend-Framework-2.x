<?php

return array(
		'controllers'	=> array(
				'invokables'	=> array(
						'Training\Controller\Test'		=> 'Training\Controller\LocalDevelopemnyController',
				)
		),
);
