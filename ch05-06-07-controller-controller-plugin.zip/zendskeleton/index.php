<?php
	include 'public/index.php';