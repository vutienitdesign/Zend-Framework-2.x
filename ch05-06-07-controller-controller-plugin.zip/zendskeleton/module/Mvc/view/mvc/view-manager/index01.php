<?php 
	echo '<h3 style="color:red;font-weight:bold">' . __FILE__ . '</h3>';
?>